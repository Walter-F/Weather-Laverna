﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Weather
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();

            WebRequest request = WebRequest.Create("https://api.openweathermap.org/data/2.5/weather?q=Kazan&units=metric&appid=b8c6e5ed005720452fe75da9cce3d2ee");

            request.Method = "POST";

            request.ContentType = "application/x-www-urlencoded";

            WebResponse response = request.GetResponse();

            string Answer = string.Empty;

            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    Answer = reader.ReadToEnd();
                }
            }

            response.Close();

            WeatherClasses.OpenWeather openWeather = JsonConvert.DeserializeObject<WeatherClasses.OpenWeather>(Answer);

            CurrentCity.Text = City.Text.ToString();
            Temperature.Text = openWeather.main.temp.ToString() + " С°";
            Description.Text = openWeather.weather[0].description.ToString()[0].ToString().ToUpper() + openWeather.weather[0].description.ToString().Remove(0, 1);
            WindSpeed.Text = openWeather.wind.speed.ToString() + " м/с";

        }

        private async void Confirm_Click(object sender, EventArgs e)
        {
            try
            {
                WebRequest request = WebRequest.Create($"https://api.openweathermap.org/data/2.5/weather?q={City.Text}&units=metric&appid=b8c6e5ed005720452fe75da9cce3d2ee");

                request.Method = "POST";

                request.ContentType = "application/x-www-urlencoded";

                WebResponse response = await request.GetResponseAsync();

                string Answer = string.Empty;

                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        Answer = await reader.ReadToEndAsync();
                    }
                }

                response.Close();

                WeatherClasses.OpenWeather openWeather = JsonConvert.DeserializeObject<WeatherClasses.OpenWeather>(Answer);

                CurrentCity.Text = City.Text.ToString();
                Temperature.Text = openWeather.main.temp.ToString() + " С°";
                Description.Text = openWeather.weather[0].description.ToString()[0].ToString().ToUpper() + openWeather.weather[0].description.ToString().Remove(0, 1);
                WindSpeed.Text = openWeather.wind.speed.ToString() + " м/с";


            } catch(Exception ex)
            {
                City.Text = String.Empty;
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Minimized_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
            Application.Exit();
        }
    }
}
