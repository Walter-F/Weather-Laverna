﻿namespace Weather
{
    partial class MainWindow
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.Minimized = new System.Windows.Forms.PictureBox();
            this.Close = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Info = new System.Windows.Forms.Label();
            this.Temperature = new System.Windows.Forms.Label();
            this.Description = new System.Windows.Forms.Label();
            this.WindSpeed = new System.Windows.Forms.Label();
            this.CurrentCity = new System.Windows.Forms.Label();
            this.Confirm = new Weather.Components.RoundButton();
            ((System.ComponentModel.ISupportInitialize)(this.Minimized)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // Minimized
            // 
            this.Minimized.BackgroundImage = global::Weather.Properties.Resources.Expand;
            this.Minimized.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimized.Location = new System.Drawing.Point(982, 12);
            this.Minimized.Name = "Minimized";
            this.Minimized.Size = new System.Drawing.Size(50, 50);
            this.Minimized.TabIndex = 0;
            this.Minimized.TabStop = false;
            this.Minimized.Click += new System.EventHandler(this.Minimized_Click);
            // 
            // Close
            // 
            this.Close.BackgroundImage = global::Weather.Properties.Resources.Close;
            this.Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close.Location = new System.Drawing.Point(1038, 12);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(50, 50);
            this.Close.TabIndex = 1;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(114, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 65);
            this.label1.TabIndex = 2;
            this.label1.Text = "Выберите желаемый город для получения данных о погоде";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // City
            // 
            this.City.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F);
            this.City.Location = new System.Drawing.Point(160, 250);
            this.City.Multiline = true;
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(245, 58);
            this.City.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(608, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 37);
            this.label2.TabIndex = 5;
            this.label2.Text = "Температура:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(608, 308);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 37);
            this.label3.TabIndex = 6;
            this.label3.Text = "Описание:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(608, 345);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 37);
            this.label4.TabIndex = 7;
            this.label4.Text = "Скорость ветра:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Weather.Properties.Resources.Weather;
            this.pictureBox3.Location = new System.Drawing.Point(787, 80);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // Info
            // 
            this.Info.BackColor = System.Drawing.Color.Transparent;
            this.Info.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Info.Location = new System.Drawing.Point(688, 183);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(306, 37);
            this.Info.TabIndex = 9;
            this.Info.Text = "Данные о погоде в городе";
            this.Info.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Temperature
            // 
            this.Temperature.BackColor = System.Drawing.Color.Transparent;
            this.Temperature.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Temperature.Location = new System.Drawing.Point(812, 271);
            this.Temperature.Name = "Temperature";
            this.Temperature.Size = new System.Drawing.Size(220, 37);
            this.Temperature.TabIndex = 10;
            this.Temperature.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Description
            // 
            this.Description.BackColor = System.Drawing.Color.Transparent;
            this.Description.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Description.Location = new System.Drawing.Point(812, 308);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(220, 37);
            this.Description.TabIndex = 11;
            this.Description.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WindSpeed
            // 
            this.WindSpeed.BackColor = System.Drawing.Color.Transparent;
            this.WindSpeed.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WindSpeed.Location = new System.Drawing.Point(812, 345);
            this.WindSpeed.Name = "WindSpeed";
            this.WindSpeed.Size = new System.Drawing.Size(220, 37);
            this.WindSpeed.TabIndex = 12;
            this.WindSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CurrentCity
            // 
            this.CurrentCity.BackColor = System.Drawing.Color.Transparent;
            this.CurrentCity.Font = new System.Drawing.Font("Yu Gothic UI Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CurrentCity.Location = new System.Drawing.Point(688, 214);
            this.CurrentCity.Name = "CurrentCity";
            this.CurrentCity.Size = new System.Drawing.Size(306, 37);
            this.CurrentCity.TabIndex = 13;
            this.CurrentCity.Text = "Kazan";
            this.CurrentCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Confirm
            // 
            this.Confirm.BackColor = System.Drawing.Color.Black;
            this.Confirm.BackColor2 = System.Drawing.Color.Black;
            this.Confirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Confirm.ButtonBorderColor = System.Drawing.Color.Black;
            this.Confirm.ButtonHighlightColor = System.Drawing.Color.Transparent;
            this.Confirm.ButtonHighlightColor2 = System.Drawing.Color.Transparent;
            this.Confirm.ButtonHighlightForeColor = System.Drawing.Color.Black;
            this.Confirm.ButtonPressedColor = System.Drawing.Color.Black;
            this.Confirm.ButtonPressedColor2 = System.Drawing.Color.Black;
            this.Confirm.ButtonPressedForeColor = System.Drawing.Color.MidnightBlue;
            this.Confirm.ButtonRoundRadius = 50;
            this.Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Confirm.Location = new System.Drawing.Point(174, 325);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(210, 70);
            this.Confirm.TabIndex = 3;
            this.Confirm.Text = "Подтвердить";
            this.Confirm.Click += new System.EventHandler(this.Confirm_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Weather.Properties.Resources.Главное_окно;
            this.ClientSize = new System.Drawing.Size(1100, 500);
            this.Controls.Add(this.CurrentCity);
            this.Controls.Add(this.WindSpeed);
            this.Controls.Add(this.Description);
            this.Controls.Add(this.Temperature);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimized);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Weather";
            ((System.ComponentModel.ISupportInitialize)(this.Minimized)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Minimized;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.Label label1;
        private Components.RoundButton Confirm;
        private System.Windows.Forms.TextBox City;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.Label Temperature;
        private System.Windows.Forms.Label Description;
        private System.Windows.Forms.Label WindSpeed;
        private System.Windows.Forms.Label CurrentCity;
    }
}

