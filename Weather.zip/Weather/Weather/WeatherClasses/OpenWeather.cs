﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weather.WeatherClasses
{
    internal class OpenWeather
    {
        public weather[] weather;
        public main main;
        public wind wind;
    }
}
